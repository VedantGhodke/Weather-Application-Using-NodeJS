# simple-nodejs-weather-app
Simple Node.js Command Line Weather Application

* Run the web app locally:
```
node server.js
// Now open your browser and visit: localhost:3000
```
![gif](https://github.com/bmorelli25/simple-nodejs-weather-app/blob/master/giphy.gif?raw=true 'website gif')

